There are three sets of sample schemas in this folder. Below is a short description for each of these schema sets.

* MultipleModelsWithSingleSSDLAndMSL
The sample demonstrates how you can split your Entity Schema into multiple smaller schemas while using a single MSL file and SSDL file. The folder contains two CSDL files - model1.csdl and model2.csdl. model2.CSDL defines a type Categories that is reused in model1.CSDL utilizing the "Using" element in CSDL. There are two other files model.ssdl which represents the store schema and model.msl which maps the Entity layer container defined in model1.CSDL to Storage layer container defined in model.ssdl.

* MultipleSchemaSets
The sample demonstrates how an EntityType can be defined in a single CSDL file and reused in multiple CSDL file. There is an EntitySet defined for the common type in each of the schemas that uses this common type and is mapped independently in both these schemas although to the same table. There are two sets of schemas in this folder - ProductDetails and CustomerDetails. Each schema set has a CSDL, SSDL and MSL file. There is one other CSDL file - CustomerBase.csdl which defines the Customer type that is reused in both ProductDetails.csdl and CustomerDetails.csdl.

* Subsetting using foreign keys
The sample demonstrates how you can map a portion of your database into an Entity Model while choosing to work with the foreign keys instead of associations in some cases since only tables on one end of foregin key may have been mapped to the Entity model. The CategoryID property in Products type in the CSDL shows up as a property instead of showing up as a Navigation property which would have been the case had Categories been part of this model.


 


